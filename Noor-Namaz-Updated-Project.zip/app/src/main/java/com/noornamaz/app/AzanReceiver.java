package com.noornamaz.app;
import android.content.*;
import android.os.Build;
public class AzanReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i){
   Intent s=new Intent(c,AzanService.class);
   s.putExtra("name",i.getStringExtra("name"));
   if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s); else c.startService(s);
 }
}
