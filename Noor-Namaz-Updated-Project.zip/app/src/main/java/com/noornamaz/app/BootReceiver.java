package com.noornamaz.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i){
   // The app asks the user to reopen it after reboot to refresh prayer-time alarms.
 }
}
