package com.noornamaz.app;
import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
public class AzanService extends Service {
 MediaPlayer player;
 @Override public void onCreate(){ super.onCreate();
   Notification n=new Notification.Builder(this,"azan").setContentTitle("Noor Namaz")
    .setContentText("Azan time").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
    .setOngoing(true).build();
   startForeground(7,n);
 }
 @Override public int onStartCommand(Intent i,int flags,int id){
   try {
     String u=getPreferences().getString("azan_uri",null);
     if(u!=null){ player=new MediaPlayer(); player.setDataSource(this,Uri.parse(u)); player.setOnCompletionListener(mp->stopSelf()); player.prepare(); player.start(); }
     else { player=MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI); if(player!=null){player.setOnCompletionListener(mp->stopSelf()); player.start();} }
   } catch(Exception e){ stopSelf(); }
   return START_NOT_STICKY;
 }
 android.content.SharedPreferences getPreferences(){ return getSharedPreferences("noor",0); }
 @Override public void onDestroy(){ if(player!=null){player.release();player=null;} super.onDestroy(); }
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
