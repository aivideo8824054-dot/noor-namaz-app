# Noor Namaz Android App

Android WebView app based on the supplied Noor Namaz text/feature outline.

## Build
GitHub Actions builds a debug APK on push to `main` or via Actions > Build Noor Namaz APK > Run workflow.

## Important notes
- The supplied source was a Markdown outline, not the original website source. This project recreates the listed sections and content; pixel-perfect matching to an unavailable original website cannot be guaranteed.
- Prayer-time calculations are approximate and must be checked against the user's local mosque timetable.
- Exact alarms require Android's exact-alarm permission on supported Android versions. Battery restrictions vary by phone.
- The current starter schedules need to be refreshed when prayer times change; do not rely on it for religiously critical timing until verified and tested.
- The app currently includes a first-pass UI and native alarm service. Boot-time rescheduling and complete daily alarm refresh are not yet implemented.
